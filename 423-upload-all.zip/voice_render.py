#!/usr/bin/env python3
"""Give Claudia one consistent, free voice: render each report in feed.json to an audio file
with Kokoro (open-source, offline, Apache-2.0; Piper is a lighter fallback). No account, no API key, no cost.

  pip install kokoro-onnx soundfile numpy
  python3 voice_render.py --feed feed.json --outdir voice

Run it after claudia.py files a report (or on a schedule). It only renders reports that have no
`audio` yet, writes voice/<id>.mp3 (or .wav if ffmpeg is missing) and adds "audio" to the report.
The page (claudia-voice.js) plays that file over her muted video; with no audio it falls back to
the browser's own voice. Only the published text is voiced: headline, summary, one safety line.
"""
import argparse, json, os, shutil, subprocess, sys, urllib.request

ENGINE = "kokoro"       # "kokoro" (most natural, free, Apache-2.0) or "piper"
KOKORO_VOICE = "af_heart"   # warm, natural US female. Others: af_bella, af_nicole, af_sarah, af_sky
KOKORO_SPEED = 0.96
KOKORO_BASE = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
MODEL = "en_US-hfc_female-medium"   # swap for any Piper voice: https://rhasspy.github.io/piper-samples/
BASE = "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/hfc_female/medium/"


import re
ABBR = [(r"\bUS (\d+)", r"U S \1"), (r"\bI-(\d+)", r"I \1"), (r"\bTDOT\b", "T-dot"), (r"\bNWS\b", "the National Weather Service"),
        (r"\bTN\b", "Tennessee"), (r"\bmph\b", "miles per hour"), (r"\bMM\b", "mile marker"), (r"\bvs\.?\b", "versus"),
        (r"\s[—–]\s", ", "), (r"\s*\(([^)]*)\)", r", \1,"), (r"\bBlvd\b", "Boulevard"), (r"\bHwy\b", "Highway")]


def spoken(t):
    """Make written copy sound like a person talking: expand shorthand, soften dashes, keep sentences short."""
    for pat, rep in ABBR:
        t = re.sub(pat, rep, t)
    t = t.replace("&", " and ").replace("%", " percent").replace("/", " or ")
    return " ".join(t.split())


def script(r):
    t = "Claudia Green, 423 dot news. "
    if (r.get("kind") or "").upper() == "HEARD" or r.get("confidence") == "unconfirmed":
        t += "Unconfirmed, from public radio traffic. "
    t += (r.get("headline") or "").rstrip(".") + ". " + (r.get("summary") or "")
    safety = r.get("safety") or []
    if safety:
        t += " Safety: " + safety[0]
    return spoken(t)[:700]


def kokoro_files(d):
    os.makedirs(d, exist_ok=True)
    out = []
    for n in ("kokoro-v1.0.onnx", "voices-v1.0.bin"):
        p = os.path.join(d, n)
        if not os.path.exists(p):
            print("downloading", n, "(one time)")
            urllib.request.urlretrieve(KOKORO_BASE + n, p)
        out.append(p)
    return out


def render_kokoro(files, text, wav, state={}):
    import soundfile as sf
    from kokoro_onnx import Kokoro
    if "k" not in state:
        state["k"] = Kokoro(files[0], files[1])
    # one sentence at a time with a short breath between them: this is what stops it sounding read-out
    import numpy as np
    parts, sr = [], 24000
    for sent in re.split(r"(?<=[.!?])\s+", text):
        if not sent.strip():
            continue
        x, sr = state["k"].create(sent, voice=KOKORO_VOICE, speed=KOKORO_SPEED, lang="en-us")
        parts += [x, np.zeros(int(sr * (0.32 if sent.endswith(".") else 0.2)), dtype=x.dtype)]
    sf.write(wav, np.concatenate(parts), sr)


def ensure_model(d):
    os.makedirs(d, exist_ok=True)
    for ext in (".onnx", ".onnx.json"):
        p = os.path.join(d, MODEL + ext)
        if not os.path.exists(p):
            print("downloading", MODEL + ext)
            urllib.request.urlretrieve(BASE + MODEL + ext, p)
    return os.path.join(d, MODEL + ".onnx")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feed", default="feed.json")
    ap.add_argument("--outdir", default="voice")
    ap.add_argument("--models", default="voice-models")
    ap.add_argument("--redo", action="store_true", help="re-render every report")
    a = ap.parse_args()

    feed = json.load(open(a.feed, encoding="utf-8"))
    todo = [r for r in feed.get("reports", []) if a.redo or not r.get("audio")]
    if not todo:
        print("nothing to render"); return
    kfiles = kokoro_files(a.models) if ENGINE == "kokoro" else None
    model = ensure_model(a.models) if ENGINE == "piper" else None
    os.makedirs(a.outdir, exist_ok=True)
    mp3 = shutil.which("ffmpeg")
    for r in todo:
        wav = os.path.join(a.outdir, r["id"] + ".wav")
        if ENGINE == "kokoro":
            render_kokoro(kfiles, script(r), wav)
        else:
            subprocess.run([sys.executable, "-m", "piper", "-m", model, "-f", wav],
                           input=script(r).encode(), check=True)
        out = wav
        if mp3:
            out = os.path.join(a.outdir, r["id"] + ".mp3")
            subprocess.run([mp3, "-v", "error", "-y", "-i", wav, "-b:a", "64k", out], check=True)
            os.remove(wav)
        r["audio"] = out.replace(os.sep, "/")
        print("voiced", r["id"], "->", r["audio"])
    json.dump(feed, open(a.feed, "w", encoding="utf-8"), indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
